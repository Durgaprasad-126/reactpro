# Card Component Design Using React JS | Props - React
https://www.youtube.com/watch?v=L3YjUUxBWgs

![HitCount](https://i.ytimg.com/vi/L3YjUUxBWgs/maxresdefault.jpg)
